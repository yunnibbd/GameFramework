### Search before asking

- [ ] I searched the [issues](https://github.com/alibaba/async_simple/issues) and found no similar issues.


### What happened + What you expected to happen


### Reproduction way


### Anything else


### Are you willing to submit a PR?

- [ ] Yes I am willing to submit a PR!
